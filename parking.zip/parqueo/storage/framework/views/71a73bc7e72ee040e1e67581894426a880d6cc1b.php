<?php $__env->startSection('subhead-custom'); ?>
<div class="d-flex">
    <form action="<?php echo e(route('search_request')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="search" name="keyword" value="<?php echo e(@$keyword); ?>">
        <button type="submit" class="btn btn-primary">Buscar</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-admin'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <table class="table table-striped table-blue-light">
        <thead>
        <tr>
            <th scope="col">Nombre</th>
            <th scope="col">CI</th>
            <th scope="col">Email</th>
            <th scope="col">
                <button onclick="selectedAll()" type="button" class="btn btn-primary bg-blue-dark">
                    Seleccionar Todo
                </button>
                <button
                    type="button"
                    onclick="addDataChecks()"
                    class="btn btn-primary bg-blue-dark"
                    data-bs-toggle="modal"
                    data-bs-target="#assign-modal"
                >
                    Asignar Parqueo
                </button>
                <button
                    type="button"
                    class="btn btn-primary bg-blue-dark"
                    data-bs-toggle="modal"
                    data-bs-target="#reject-modal"
                    onclick="addDataChecks('selected_checks_reject')"
                >
                    Rechazar
                </button>
            </th>

        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($request->user->name); ?></td>
                <td><?php echo e($request->user->ci); ?></td>
                <td><?php echo e($request->user->email); ?></td>
                <td>
                    <div class="row justify-content-center">
                        <div class="col-3">
                            <a
                                href=""
                                class="text-blue-dark text-decoration-none"
                                data-bs-toggle="modal"
                                data-bs-target="#manual_assign_<?php echo e($request->id); ?>"
                            > ASIGNAR </a>
                        </div>
                        <div class="col-1">
                    <input type="checkbox" name="items[]" value="<?php echo e($request->id); ?>" class="form-check-input">

                        </div></div>
                    <?php if (isset($component)) { $__componentOriginal2a30ae47a4885c1b5699470a97884dd83c4fadc4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Modals\GenericModal::class, ['name' => 'manual_assign_'.e($request->id).'','title' => 'Asignar']); ?>
<?php $component->withName('generic-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                         <?php $__env->slot('content', null, ['class' => '']); ?> 
                            <form action="<?php echo e(route('request.update')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="row py-3">
                                <label for="requests_list" class="col-md-4 col-form-label text-black">Manual</label>
                                    <div class="col-md-6">

                                <select id="requests_list" class="form-control " name="parking_id" required autofocus>
                                    <option value="" > Selecciona Parking Manual</option>
                                    <?php $__currentLoopData = $parkings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(@$request->parking_id && @$request->parking_id === $parking->id): ?>
                                            <option
                                                value="<?php echo e($parking->id); ?>"
                                                selected
                                            >
                                                <?php echo e($parking->name); ?>

                                            </option>
                                        <?php endif; ?>
                                        <?php if($parking->status==='available'): ?>
                                          <option
                                              value="<?php echo e($parking->id); ?>"
                                          >
                                              <?php echo e($parking->name); ?>

                                          </option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                                        <input type="hidden" value="<?php echo e(@$request->id); ?>" name="request_id">
                                    </div>
                                </div>
                                <div class="row justify-content-center">
                                    <div class="col-4">
                                        <button type="button" class="btn btn-secondary bg-blue-dark"
                                                data-bs-dismiss="modal">Cerrar</button>
                                    </div>
                                    <div class="col-4">
                                        <button type="submit" class="btn btn-secondary bg-blue-dark"
                                                data-bs-dismiss="modal">Aceptar</button>
                                    </div>
                                </div>
                            </form>
                         <?php $__env->endSlot(); ?>
                         <?php $__env->slot('buttons', null, ['class' => '']); ?>  <?php $__env->endSlot(); ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2a30ae47a4885c1b5699470a97884dd83c4fadc4)): ?>
<?php $component = $__componentOriginal2a30ae47a4885c1b5699470a97884dd83c4fadc4; ?>
<?php unset($__componentOriginal2a30ae47a4885c1b5699470a97884dd83c4fadc4); ?>
<?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
        <?php if (isset($component)) { $__componentOriginal2a30ae47a4885c1b5699470a97884dd83c4fadc4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Modals\GenericModal::class, ['name' => 'assign-modal','title' => 'Confirmar']); ?>
<?php $component->withName('generic-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
             <?php $__env->slot('content', null, ['class' => '']); ?> 
                <form action="<?php echo e(route('request.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <p>
                        ¿Desea aceptar esta cuenta?
                    </p>
                    <input type="hidden" id="selected_checks" name="request_ids">
                    <div class="row justify-content-center">
                        <div class="col-4">
                            <button type="button" class="btn btn-secondary bg-blue-dark"
                                    data-bs-dismiss="modal">Cerrar</button>
                        </div>
                        <div class="col-4">
                            <button type="submit" class="btn btn-secondary bg-blue-dark"
                                    data-bs-dismiss="modal">Aceptar</button>
                        </div>
                    </div>
                </form>
             <?php $__env->endSlot(); ?>
             <?php $__env->slot('buttons', null, ['class' => '']); ?>  <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2a30ae47a4885c1b5699470a97884dd83c4fadc4)): ?>
<?php $component = $__componentOriginal2a30ae47a4885c1b5699470a97884dd83c4fadc4; ?>
<?php unset($__componentOriginal2a30ae47a4885c1b5699470a97884dd83c4fadc4); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal2a30ae47a4885c1b5699470a97884dd83c4fadc4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Modals\GenericModal::class, ['name' => 'reject-modal','title' => 'Confirmar']); ?>
<?php $component->withName('generic-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('content', null, ['class' => '']); ?> 
            <form action="<?php echo e(route('request.delete')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <p>
                    ¿Deseas rechazar la(s) solicitud(es)?
                </p>
                <input type="hidden" id="selected_checks_reject" name="request_ids">
                <div class="row justify-content-center">
                    <div class="col-4">
                        <button type="button" class="btn btn-secondary bg-blue-dark"
                                data-bs-dismiss="modal">Cerrar</button>
                    </div>
                    <div class="col-4">
                        <button type="submit" class="btn btn-secondary bg-blue-dark"
                                data-bs-dismiss="modal">Aceptar</button>
                    </div>
                </div>
            </form>
         <?php $__env->endSlot(); ?>
         <?php $__env->slot('buttons', null, ['class' => '']); ?>  <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2a30ae47a4885c1b5699470a97884dd83c4fadc4)): ?>
<?php $component = $__componentOriginal2a30ae47a4885c1b5699470a97884dd83c4fadc4; ?>
<?php unset($__componentOriginal2a30ae47a4885c1b5699470a97884dd83c4fadc4); ?>
<?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        function selectedAll(){
            $('input[type="checkbox"]').prop('checked', true);
        }
        function addDataChecks(name='selected_checks'){
            let checked = []
            $("input[name='items[]']:checked").each(function ()
            {
                checked.push(parseInt($(this).val()));
            });
            $('#'+name).val(checked.join(','));
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ivanovic/Desktop/Projects/laravell/project parqueo/repositori/Tis2023/parqueo/resources/views/pages/requests/list.blade.php ENDPATH**/ ?>