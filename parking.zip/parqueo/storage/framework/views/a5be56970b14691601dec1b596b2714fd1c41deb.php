<?php $__env->startSection('content-admin'); ?>
    <div class="container">
        <div class="w-100 px-3">
            <div class="row align-items-center justify-content-center pt-3">
                <div class="col-4">
                    <div>
                        <div class="mb-4">
                            <a href="<?php echo e(url('/reports/users')); ?>" class="d-flex flex-column btn btn-secondary bg-blue-dark">Usuarios</a>
                        </div>
                        <div class="mb-4">
                            <a href="<?php echo e(url('/reports/payments')); ?>" class="d-flex flex-column btn btn-secondary bg-blue-dark">Pagos</a>
                        </div>
                        <div class="mb-4">
                            <a href="<?php echo e(url('/reports/announcement')); ?>" class="d-flex flex-column btn btn-secondary bg-blue-dark">Convocatoria</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ivanovic/Desktop/Projects/laravell/project parqueo/repositori/Tis2023/parqueo/resources/views/pages/reports/reports.blade.php ENDPATH**/ ?>