<?php $__env->startSection('content'); ?>
    <div class="main-content-panel position-fixed h-100 w-100 d-flex general-container">
        <nav class="navbar-content-fix bg-blue-dark-light h-100">
            <div>
                <div class="title-nav d-flex align-items-center justify-content-center">
                    <?php echo e(auth()->user()->load(['rol'])->rol->nom_role); ?>

                </div>
                <hr>
            </div>
            <div>

                <ul class="list-unstyled ps-3">

                    <?php if(@auth()->user()->rol->nom_role!=="GUARDIA"): ?>
                    <li>
                        <a class="<?php if(@$type_list === 'cliente'): ?> active-item-nav <?php endif; ?> text-dark text-decoration-none btn-item-nav btn "
                            href="<?php echo e(url('/home')); ?>">Lista Clientes </a>
                    </li>
                    <li>
                        <a class="<?php if(@$type_list === 'request'): ?> active-item-nav <?php endif; ?> text-dark text-decoration-none btn-item-nav btn"
                            href="<?php echo e(url('/requests')); ?>">Solicitud Clientes </a>
                    </li>
                    <li>
                        <a class="<?php if(@$type_list === 'employee'): ?> active-item-nav <?php endif; ?> text-dark text-decoration-none btn-item-nav btn"
                            href="<?php echo e(url('/employees')); ?>">Lista de Empleados </a>
                    </li>
                    <li>
                        <a class="<?php if(@$type_list === 'schedules'): ?> active-item-nav <?php endif; ?> text-dark text-decoration-none btn-item-nav btn"
                            href="<?php echo e(url('/horarios')); ?>">Lista de Horarios </a>
                    </li>
                    <li>
                        <a class="<?php if(@$type_list === 'claims'): ?> active-item-nav <?php endif; ?> text-dark text-decoration-none btn-item-nav btn"
                           href="<?php echo e(url('/claims')); ?>">Reclamos</a>
                    </li>
                    <li>
                        <a class="<?php if(@$type_list === 'parking'): ?> active-item-nav <?php endif; ?> text-dark text-decoration-none btn-item-nav btn"
                           href="<?php echo e(url('/parking')); ?>">Parquero</a>
                    </li>
                    <li>
                        <a class="<?php if(@$type_list === 'reports'): ?> active-item-nav <?php endif; ?> text-dark text-decoration-none btn-item-nav btn"
                           href="<?php echo e(url('/reports')); ?>">Reportes</a>
                    </li>
                    <li>
                        <a class="<?php if(@$type_list === 'conversations'): ?> active-item-nav <?php endif; ?> text-dark text-decoration-none btn-item-nav btn"
                           href="<?php echo e(url('/conversations')); ?>">Mensajes</a>
                    </li>
                    <?php endif; ?>
                    <?php if(@auth()->user()->rol->nom_role==="GUARDIA"): ?>
                        <li>
                            <a class="<?php if(@$type_list === 'parking'): ?> active-item-nav <?php endif; ?> text-dark text-decoration-none btn-item-nav btn"
                               href="<?php echo e(url('/parking')); ?>">Parquero</a>
                        </li>
                        <li>
                            <a class="<?php if(@$type_list === 'conversations'): ?> active-item-nav <?php endif; ?> text-dark text-decoration-none btn-item-nav btn"
                               href="<?php echo e(url('/conversations')); ?>">Mensajes</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </nav>
        <div class="w-100 overflow-auto">
            <div class="bg-blue-dark-light-2 d-flex justify-content-between py-3 px-3">
                <h4 class="text-pink-light"><?php echo e(@$title); ?></h4>
                <?php echo $__env->yieldContent('subhead-custom'); ?>
                <div>
                    <div class=" dropdown  item-avatar">
                        <div id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button"
                            data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            <div class="rounded-circle py-2 px-3 text-blue-dark bg-pink-light">
                                <?php echo e(substr(Auth::user()->name, 0, 1)); ?>

                            </div>
                        </div>

                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                <?php echo e(__('Logout')); ?>

                            </a>

                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </div>
                </div>

            </div>

            <?php echo $__env->yieldContent('content-admin'); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts_news'); ?>
    <?php echo $__env->yieldContent('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ivanovic/Desktop/Projects/laravell/project parqueo/repositori/Tis2023/parqueo/resources/views/layouts/admin.blade.php ENDPATH**/ ?>