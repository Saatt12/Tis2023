<?php $__env->startSection('content-admin'); ?>
    <div >
        <a href="<?php echo e(route('horario.create')); ?>" class="btn btn-primary m-2"> Añadir Horario</a>
    </div>
    <table class="table table-striped table-blue-light">
        <thead>
        
        </thead>
        <tbody>
        <?php $__currentLoopData = $horarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $horario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($horario->nom_turno); ?></td>
                <td><?php echo e($horario->hora_entrada); ?> - <?php echo e($horario->hora_salida); ?></td>
                <td>
                    <a type="button" class="text-decoration-none me-3" href="<?php echo e(route('horario.show', ['id' => $horario->id])); ?>">
                        Editar
                    </a>
                    <a type="button" class="text-decoration-none text-red-cherry" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                        Eliminar
                    </a>

                    <!-- Modal -->
                    <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                                <div class="modal-header bg-red-cherry text-pink-light justify-content-center">
                                    <h1 class="modal-title fs-5 text-center" id="staticBackdropLabel">Confirmar </h1>
                                </div>
                                <div class="modal-body">
                                    <div class="text-center">
                                        ¿Deseas eliminar  esta cuenta?
                                        <form action="/horarios/<?php echo e($horario->id); ?>" method="POST" class="mt-3">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>

                                            <button type="button" class="btn btn-secondary bg-blue-dark" data-bs-dismiss="modal">Cancelar</button>
                                            <button type="submit" class="btn btn-primary bg-blue-dark">Aceptar</button>

                                        </form>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ivanovic/Desktop/Projects/laravell/project parqueo/repositori/Tis2023/parqueo/resources/views/pages/horarios/list.blade.php ENDPATH**/ ?>