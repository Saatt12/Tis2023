<?php $__env->startSection('content'); ?>
    <div class="main-content-panel position-fixed h-100 w-100 d-flex general-container z-i-101">
        
        <div class="w-100 overflow-auto">
            <div class="bg-blue-dark-light-2 d-flex justify-content-between py-3 px-3">
                <h4 class="text-pink-light"><?php echo e(@$title); ?></h4>
                <div>
                    <div class="dropdown">
                        <button class="btn btn-primary bg-blue-dark dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                            Notificaciones
                                <span class="bg-blue-dark-light-2 badge badge-light">
                                    <?php echo e($notifications && sizeof($notifications)>0?sizeof($notifications):0); ?>

                                </span>
                        </button>
                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                            <?php if($notifications && sizeof($notifications)>0): ?>
                                <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <div class="text-center border border border-primary m-2">
                                            <h5><?php echo e($notification->title); ?></h5>
                                            <p class="m-0">
                                                <?php echo e($notification->content); ?>

                                            </p>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <form id="clear_notification" method="POST" action="<?php echo e(route('clear_notification')); ?>">
                                    <?php echo csrf_field(); ?>
                                   <button type="submit" class="btn btn-danger small">Limpiar Notificaciones</button>
                                </form>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
                <div>
                    <div class=" dropdown  item-avatar">
                        <div id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button"
                            data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            <div class="rounded-circle py-2 px-3 text-blue-dark bg-pink-light">
                                <?php echo e(substr(Auth::user()->name, 0, 1)); ?>

                            </div>
                        </div>
                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                <?php echo e(__('Logout')); ?>

                            </a>

                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <?php echo $__env->yieldContent('content-admin'); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts_news'); ?>
    <?php echo $__env->yieldContent('scripts'); ?>
    <script>
        $("#clear_notification").validate({
            submitHandler: function(form) {
                let token = $('meta[name="csrf-token"]').attr('content');
                $.ajax({
                    type: 'POST',
                    url: $(form).attr('action'),
                    processData: false,
                    contentType: false,
                    enctype: 'multipart/form-data',
                    headers: {
                        'X-CSRF-TOKEN': token
                    },
                    success: function(response) {
                        console.log("-> response", response);
                        /*$('#payment_mode_').modal('hide')
                        $('#success_payment_modal_').modal('show')*/
                        location.reload()
                    },
                    error: function(xhr, status, error) {
                        console.log("-> error", error);
                    }
                });
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ivanovic/Desktop/Projects/laravell/project parqueo/repositori/Tis2023/parqueo/resources/views/layouts/client.blade.php ENDPATH**/ ?>