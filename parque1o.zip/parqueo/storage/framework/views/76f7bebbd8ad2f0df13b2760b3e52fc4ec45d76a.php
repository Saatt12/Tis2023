<?php $__env->startSection('content-admin'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if(@$user_permission->contains('responder_reclamo_multiple')): ?>
    <a href="<?php echo e(url('/messages_emails')); ?>" class="btn btn-primary my-2">Enviar Mensajess </a>
    <?php endif; ?>
    <table class="table table-striped table-blue-light">
        <thead>
        <tr>
            <th scope="col">Nombre</th>
            <th scope="col">CI</th>
            <th scope="col">Email</th>
            <th scope="col">
                <?php if(@$user_permission->contains('eliminar_reclamo')): ?>
                <button onclick="selectedAll()" type="button" class="btn btn-primary bg-blue-dark">
                    Seleccionar Todo
                </button>
                <button
                    type="button"
                    class="btn btn-primary bg-blue-dark"
                    data-bs-toggle="modal"
                    data-bs-target="#reject-modal"
                    onclick="addDataChecks('claims_requests')"
                >
                    Eliminar
                </button>
                <?php endif; ?>
            </th>

        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $claims; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $claim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($claim->user->name); ?></td>
                <td><?php echo e($claim->user->ci); ?></td>
                <td><?php echo e($claim->user->email); ?></td>
                <td>
                    <?php if(@$user_permission->contains('responder_reclamo_individual')): ?>
                    <div class="row justify-content-center">
                        <div class="col-3">
                            <a
                                href="<?php echo e(url('/claims_messages/'.$claim->id)); ?>"
                                class="text-blue-dark text-decoration-none"
                            > Ver </a>
                        </div>
                        <div class="col-1">
                    <input type="checkbox" name="items[]" value="<?php echo e($claim->id); ?>" class="form-check-input">

                        </div></div>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php if (isset($component)) { $__componentOriginal2a30ae47a4885c1b5699470a97884dd83c4fadc4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Modals\GenericModal::class, ['name' => 'reject-modal','title' => 'Confirmar']); ?>
<?php $component->withName('generic-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('content', null, ['class' => '']); ?> 
            <form action="<?php echo e(route('messages_emails.delete')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <p>
                    ¿Deseas eliminar estos reclamos?
                </p>
                <input type="hidden" id="claims_requests" name="claim_ids">
                <div class="row justify-content-center">
                    <div class="col-4">
                        <button type="button" class="btn btn-secondary bg-blue-dark"
                                data-bs-dismiss="modal">Cerrar</button>
                    </div>
                    <div class="col-4">
                        <button type="submit" class="btn btn-secondary bg-blue-dark"
                                data-bs-dismiss="modal">Aceptar</button>
                    </div>
                </div>
            </form>
         <?php $__env->endSlot(); ?>
         <?php $__env->slot('buttons', null, ['class' => '']); ?>  <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2a30ae47a4885c1b5699470a97884dd83c4fadc4)): ?>
<?php $component = $__componentOriginal2a30ae47a4885c1b5699470a97884dd83c4fadc4; ?>
<?php unset($__componentOriginal2a30ae47a4885c1b5699470a97884dd83c4fadc4); ?>
<?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        function selectedAll(){
            $('input[type="checkbox"]').prop('checked', true);
        }
        function addDataChecks(name='selected_checks'){
            let checked = []
            $("input[name='items[]']:checked").each(function ()
            {
                checked.push(parseInt($(this).val()));
            });
            $('#'+name).val(checked.join(','));
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ivanovic/Desktop/Projects/laravell/project parqueo/repositori/Tis2023/parqueo/resources/views/pages/claims/list.blade.php ENDPATH**/ ?>