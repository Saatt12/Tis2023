<?php $__env->startSection('content-admin'); ?>
    <div >
         <?php if(@$user_permission->contains('crear_unidad')): ?>
        <a href="<?php echo e(route('unidad.create')); ?>" class="btn btn-primary m-2"> Añadir Cargo</a>
        <?php endif; ?>
    </div>
    <table class="table table-striped table-blue-light">
        <thead>
        <tr>
            <th scope="col">Nombre</th>
            <th></th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $unidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($unidad->nom_unidad); ?></td>
                <td>
                     <?php if(@$user_permission->contains('editar_unidad')): ?>
                    <a type="button" class="text-decoration-none me-3" href="<?php echo e(route('unidad.show', ['id' => $unidad->id])); ?>">
                        Editar
                    </a>
                    <?php endif; ?>
                     <?php if(@$user_permission->contains('eliminar_unidad')): ?>
                    <a type="button" class="text-decoration-none text-red-cherry" data-bs-toggle="modal" data-bs-target="#staticBackdrop<?php echo e($unidad->id); ?>">
                        Eliminar
                    </a>
                     <?php endif; ?>

                    <!-- Modal -->
                    <div class="modal fade" id="staticBackdrop<?php echo e($unidad->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                                <div class="modal-header bg-red-cherry text-pink-light justify-content-center">
                                    <h1 class="modal-title fs-5 text-center" id="staticBackdropLabel">Confirmar </h1>
                                </div>
                                <div class="modal-body">
                                    <div class="text-center">
                                        ¿Deseas eliminar  este unidad?
                                        <form action="/unidades/<?php echo e($unidad->id); ?>" method="POST" class="mt-3">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="button" class="btn btn-secondary bg-blue-dark" data-bs-dismiss="modal">Cancelar</button>
                                            <button type="submit" class="btn btn-primary bg-blue-dark">Aceptar</button>

                                        </form>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ivanovic/Desktop/Projects/laravell/project parqueo/repositori/Tis2023/parqueo/resources/views/pages/unidades/list.blade.php ENDPATH**/ ?>