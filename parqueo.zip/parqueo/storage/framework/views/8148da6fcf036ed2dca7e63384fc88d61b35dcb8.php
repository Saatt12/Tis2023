<?php $__env->startSection('content-admin'); ?>
    <div class="row">
        <div class="col-1 d-flex flex-column align-items-center justify-content-center">
            <a class="btn btn-primary bg-blue-dark" href="<?php echo e(url('/reports')); ?>">
                Atras
            </a>
        </div>
        <div class="col-10">
            <form class="row my-3" action="<?php echo e(route('search_report_announcement')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                    <div class="col-5 mb-3">
                        <div class="row">
                        <label for="date_initial" class="col-6 col-form-label">fecha inicial</label>
                        <div class="col-6">
                            <input id="date_initial" type="date"
                                   class="form-control" name="date_initial"
                                   value="<?php echo e($date_initial); ?>">
                        </div>
                        </div>
                    </div>
                    <div class="col-5 mb-3">
                        <div class="row">
                        <label for="date_fin" class="col-6 col-form-label">fecha final</label>

                        <div class="col-6">
                            <input id="date_fin" type="date"
                                   class="form-control" name="date_fin"
                                   value="<?php echo e($date_fin); ?>" >

                        </div>
                        </div>
                    </div>

                <div class="col-1 d-flex flex-column align-items-center justify-content-center">
                    <div class="">
                        <button type="submit" class="btn btn-primary bg-blue-dark">
                            Buscar
                        </button>
                    </div>
                </div>
            </form>
        </div>
        <div class="col-1 d-flex flex-column align-items-center justify-content-center">
            <form method="POST" action="<?php echo e(route('export_report_announcement')); ?>" target="_blank">
                <?php echo csrf_field(); ?>
                <input id="date_initial" type="hidden" value="<?php echo e($date_initial); ?>" name="date_initial">
                <input id="date_initial" type="hidden" value="<?php echo e($date_fin); ?>" name="date_fin">
                <button type="submit" class="btn btn-primary bg-blue-dark"> PDF</button>
            </form>
        </div>
    </div>
    <table class="table table-striped table-blue-light">
        <thead>
        <tr>
            <th scope="col">fecha emision</th>
            <th scope="col">fecha fin emision</th>
            <th scope="col">Descuento</th>
            <th scope="col">Multa</th>
            <th scope="col">Monto mensual </th>
            <th scope="col">Monto anual</th>
            <th scope="col">Cantidad Esp</th>
            <th scope="col">Imagen</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $announcements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $announcement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="col"><?php echo e($announcement->fecha_inicio); ?></th>
                <th scope="col"><?php echo e($announcement->fecha_fin); ?></th>
                <th scope="col"><?php echo e($announcement->descuento); ?></th>
                <th scope="col"><?php echo e($announcement->multa); ?></th>
                <th scope="col"><?php echo e($announcement->monto_mes); ?> </th>
                <th scope="col"><?php echo e($announcement->monto_anual); ?></th>
                <th scope="col"><?php echo e($announcement->cantidad_espacios); ?></th>
                <th scope="col">
                    <img src="<?php echo e(asset('storage/'.$announcement->image)); ?>" alt=""  style="max-width: 100px">
                   </th>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ivanovic/Desktop/Projects/laravell/project parqueo/repositori/Tis2023/parqueo/resources/views/pages/reports/reports_announcement.blade.php ENDPATH**/ ?>