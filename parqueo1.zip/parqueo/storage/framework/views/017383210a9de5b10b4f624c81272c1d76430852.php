<!DOCTYPE html>
<html lang="es">
<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Factura</title>
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <div class="col-xs-10 ">
            <h1>Factura</h1>
        </div>
        <div class="col-xs-2">

        </div>
    </div>
    <hr>
    <div class="row">
        <div class="col-xs-10">
            <h1 class="h6"> Universidad Mayor de San Simon</h1>
            <h1 class="h6"> http://www.fcyt.umss.edu.bo/</h1>
        </div>
        <div class="col-xs-2 text-center">
            <strong>Fecha</strong>
            <br>
             <?php echo e(Carbon\Carbon::now()); ?>

            <br>
            <strong>Factura No.</strong>
            <br>
             <?php echo e($data->id); ?>

        </div>
    </div>
    <hr>
    <div class="row text-center" style="margin-bottom: 2rem;">
        <div class="col-xs-6">
            <h1 class="h2">Cliente</h1>
            <strong> <?php echo e($data->user->name); ?></strong>
        </div>
        <div class="col-xs-6">
            <h1 class="h2">Remitente</h1>
            <strong> fcyt.umss.edu.bo </strong>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12">
            <table class="table table-condensed table-bordered table-striped">
                <thead>
                <tr>
                    <th>Descripción</th>
                    <th>Fecha de Emision</th>
                    <th>Modalidad de Pago</th>
                    <th>Total</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td> Pago en relacion al servicio de Parqueo segun la convocatoria <?php echo e($data->announcement->fecha_inicio); ?> / <?php echo e($data->announcement->fecha_fin); ?></td>
                    <td><?php echo e($data->created_at); ?></td>
                    <td><?php echo e($data->plan); ?></td>
                    <td><?php echo e($data->amount); ?> Bs.</td>
                </tr>

                </tbody>
                <tfoot>
                
                <tr>
                    <td colspan="3" class="text-right">
                        <h4>Total</h4></td>
                    <td>
                        <h4><?php echo e($data->amount); ?> Bs.</h4>
                    </td>
                </tr>
                </tfoot>
            </table>
        </div>
    </div>
    <div class="row">
        <div class="col-xs-12 text-center">
            <p class="h5"> <?php echo e($mensajePie); ?></p>
        </div>
    </div>
</div>
</body>
</html>
<?php /**PATH /home/ivanovic/Desktop/Projects/laravell/project parqueo/repositori/Tis2023/parqueo/resources/views/page_client/template_export/factura.blade.php ENDPATH**/ ?>