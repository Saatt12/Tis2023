<?php $__env->startSection('content-admin'); ?>
    <div class="row">
        <div class="col-1 d-flex flex-column align-items-center justify-content-center">
            <a class="btn btn-primary bg-blue-dark" href="<?php echo e(url('/reports')); ?>">
                Atras
            </a>
        </div>
        <div class="col-10">
        <form class="row my-3" action="<?php echo e(route('search_report_users')); ?>" method="POST">
            <?php echo csrf_field(); ?>
               <div class="col-2 d-flex flex-column align-items-center justify-content-center">
                   <select id="announcement" class="form-control <?php $__errorArgs = ['announcement_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           name="announcement_id" autofocus>
                       <option value="" <?php echo e(!@$announcement_id ? 'selected' : ''); ?>> Convocatoria</option>
                       <?php $__currentLoopData = $announcements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $announcement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <option value="<?php echo e($announcement->id); ?>" <?php echo e($announcement->id === @$announcement_id ? 'selected' : ''); ?>><?php echo e($announcement->fecha_inicio); ?> - <?php echo e($announcement->fecha_fin); ?></option>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </select>
               </div>
               <div class="col-5">
               <div class="row mb-3">
                   <label for="date_initial" class="col-6 col-form-label">fecha inicial de registro</label>
                   <div class="col-6">
                       <input id="date_initial" type="date"
                              class="form-control <?php $__errorArgs = ['date_initial'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="date_initial"
                              value="<?php echo e($date_initial); ?>" autocomplete="name" autofocus>
                       <?php $__errorArgs = ['date_initial'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                       <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($message); ?></strong>
                       </span>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                   </div>
               </div>
               <div class="row mb-3">
                   <label for="date_fin" class="col-6 col-form-label">fecha final de registro</label>

                   <div class="col-6">
                       <input id="date_fin" type="date"
                              class="form-control <?php $__errorArgs = ['date_fin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="date_fin"
                              value="<?php echo e($date_fin); ?>" autocomplete="name" autofocus>

                       <?php $__errorArgs = ['date_fin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($message); ?></strong>
                        </span>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                   </div>
               </div>
               </div>
               <div class="col-4 d-flex flex-column align-items-center justify-content-center">
                   <div class="row">
                       <div class="col-3 d-flex flex-column align-items-center justify-content-center">
                            <label for="name" class="">Usuario</label>
                       </div>
                       <div class="col-9">
                       <input id="name" type="text"
                              class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name"
                              value="<?php echo e($name); ?>" autocomplete="name" autofocus>

                       <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                       <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($message); ?></strong>
                       </span>
                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                       </div>
                   </div>

               </div>

               <div class="col-1 d-flex flex-column align-items-center justify-content-center">
                   <div class="">
                       <button type="submit" class="btn btn-primary bg-blue-dark">
                           Buscar
                       </button>
                   </div>
               </div>
        </form>
        </div>
        <div class="col-1 d-flex flex-column align-items-center justify-content-center">
            <form method="POST" action="<?php echo e(route('export_report_users')); ?>" target="_blank">
                <?php echo csrf_field(); ?>
                <input id="date_initial" type="hidden" value="<?php echo e($announcement_id); ?>" name="announcement_id">
                <input id="date_initial" type="hidden" value="<?php echo e($date_initial); ?>" name="date_initial">
                <input id="date_initial" type="hidden" value="<?php echo e($date_fin); ?>" name="date_fin">
                <input id="date_initial" type="hidden" value="<?php echo e($name); ?>" name="name">
                <button type="submit" class="btn btn-primary bg-blue-dark"> PDF</button>
            </form>
        </div>
    </div>
    <table class="table table-striped table-blue-light">
        <thead>
        <tr>
            <th scope="col">Nombre</th>
            <th scope="col">CI</th>
            <th scope="col">Email</th>
            <th scope="col">Rol</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($user['name']); ?></td>
                <td><?php echo e($user['ci']); ?></td>
                <td><?php echo e($user['email']); ?></td>
                <td><?php echo e($user->rol->nom_role); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ivanovic/Desktop/Projects/laravell/project parqueo/repositori/Tis2023/parqueo/resources/views/pages/reports/reports_users.blade.php ENDPATH**/ ?>