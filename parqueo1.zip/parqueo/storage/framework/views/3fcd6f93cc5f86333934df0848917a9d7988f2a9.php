<?php $__env->startSection('content-admin'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-8">
                <div class="modal-content pt-3">
                    <div class=" bg-red-cherry text-pink-light justify-content-center py-2">
                        <h1 class="modal-title fs-5 text-center" id="vehicle_registered_Label">Convocatorias
                        </h1>
                    </div>
                    <div class="pt-2">
                        <div class="text-center">
                            <?php $__currentLoopData = $announcements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $announcement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row w-100 mx-0 p-1 <?php echo e(@$current_announcement && $current_announcement->id===$announcement->id?'bg-grey-light':''); ?>">
                                    <div class="col-7 pb-2">
                                       Convocatoria <?php echo e($announcement->fecha_inicio); ?> | <?php echo e($announcement->fecha_fin); ?>

                                        <?php if(@$current_announcement && $current_announcement->id===$announcement->id): ?>
                                        <strong> (Vigente)</strong>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-5 pb-2">
                                        <a href="" class="btn btn-secondary bg-blue-dark"
                                           data-bs-toggle="modal"
                                           data-bs-target="#vehicle_show_<?php echo e($announcement->id); ?>"> Ver </a>
                                    </div>

                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="row justify-content-center">
                                <div class="col-4">
                                    <a type="button" class="btn btn-secondary bg-blue-dark"
                                            href="<?php echo e(url('/parking')); ?>">Cerrar</a>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
        <!-- Modal -->
        <?php $__currentLoopData = $announcements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $announcement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="modal fade" id="vehicle_show_<?php echo e($announcement->id); ?>" data-bs-backdrop="static"
                 data-bs-keyboard="false" tabindex="-1" aria-labelledby="vehicle_show_Label" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content z-i-101">
                        <div class="modal-header bg-red-cherry text-pink-light justify-content-center">
                            <h1 class="modal-title fs-5 text-center" id="vehicle_show_Label">Convocatoria</h1>
                        </div>
                        <div class="modal-body">
                            <div class="row justify-content-center mt-4">
                                <div class="col-10">
                                    <div class="row mb-3">
                                        <label for="fecha_inicio" class="col-md-4 col-form-label"> Fecha Inicio</label>

                                        <div class="col-md-6">
                                            <input readonly id="fecha_inicio" type="date"
                                                   class="form-control <?php $__errorArgs = ['fecha_inicio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="fecha_inicio"
                                                   value="<?php echo e($announcement->fecha_inicio); ?>" required autocomplete="name" autofocus>

                                            <?php $__errorArgs = ['fecha_inicio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label for="fecha_fin" class="col-md-4 col-form-label"> Fecha Fin</label>

                                        <div class="col-md-6">
                                            <input readonly id="fecha_fin" type="date"
                                                   class="form-control <?php $__errorArgs = ['fecha_fin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="fecha_fin"
                                                   value="<?php echo e($announcement->fecha_fin); ?>" required autocomplete="name" autofocus>

                                            <?php $__errorArgs = ['fecha_fin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label for="descuento" class="col-md-4 col-form-label"> Descuento</label>

                                        <div class="col-md-6">
                                            <select id="descuento" class="form-control <?php $__errorArgs = ['descuento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="descuento"
                                                    required autofocus>
                                                <option value="<?php echo e(!@$announcement->descuento); ?>" <?php echo e(!@$announcement?'selected':''); ?>> Selecciona un meses</option>
                                                <?php for($i = 1; $i <= 12; $i++): ?>
                                                    <option value="<?php echo e($i); ?>" <?php echo e(@$announcement->descuento===@$i?'selected':''); ?>> <?php echo e($i); ?>

                                                        <?php echo e($i == 1 ? 'mes' : 'meses'); ?> </option>
                                                <?php endfor; ?>
                                            </select>
                                            <?php $__errorArgs = ['descuento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label for="multa" class="col-md-4 col-form-label"> Multa</label>

                                        <div class="col-md-6">
                                            <select id="multa" class="form-control <?php $__errorArgs = ['multa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="multa"
                                                    required autofocus>
                                                <option value="<?php echo e(!@$announcement->multa); ?>" <?php echo e(!@$announcement?'selected':''); ?>> Selecciona un meses</option>
                                                <?php for($i = 1; $i <= 12; $i++): ?>
                                                    <option value="<?php echo e($i); ?>" <?php echo e(@$announcement->multa===@$i?'selected':''); ?>> <?php echo e($i); ?>

                                                        <?php echo e($i == 1 ? 'mes' : 'meses'); ?> </option>
                                                <?php endfor; ?>
                                            </select>
                                            <?php $__errorArgs = ['multa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label for="monto_mes" class="col-md-4 col-form-label"> Monto Mes</label>

                                        <div class="col-md-6">
                                            <input readonly id="monto_mes" type="number"
                                                   class="form-control <?php $__errorArgs = ['monto_mes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="monto_mes"
                                                   value="<?php echo e($announcement->monto_mes); ?>" required autocomplete="name" autofocus>

                                            <?php $__errorArgs = ['monto_mes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label for="monto_multa" class="col-md-4 col-form-label"> Monto multa</label>

                                        <div class="col-md-6">
                                            <input readonly id="monto_multa" type="number"
                                                   class="form-control <?php $__errorArgs = ['monto_multa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="monto_multa"
                                                   value="<?php echo e($announcement->monto_multa); ?>" required autocomplete="name" autofocus>

                                            <?php $__errorArgs = ['monto_multa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label for="monto_descuento" class="col-md-4 col-form-label"> Monto Descuento</label>

                                        <div class="col-md-6">
                                            <input readonly id="monto_descuento" type="number"
                                                   class="form-control <?php $__errorArgs = ['monto_descuento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="monto_descuento"
                                                   value="<?php echo e($announcement->monto_descuento); ?>" required autocomplete="name" autofocus>

                                            <?php $__errorArgs = ['monto_descuento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label for="monto_anual" class="col-md-4 col-form-label"> Monto Anual</label>

                                        <div class="col-md-6">
                                            <input readonly id="monto_anual" type="number"
                                                   class="form-control <?php $__errorArgs = ['monto_anual'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="monto_anual"
                                                   value="<?php echo e($announcement->monto_anual); ?>" required autocomplete="name" autofocus>

                                            <?php $__errorArgs = ['monto_anual'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label for="cantidad_espacios" class="col-md-4 col-form-label"> Cantidad Espacios</label>

                                        <div class="col-md-6">
                                            <input readonly id="cantidad_espacios" type="number"
                                                   class="form-control <?php $__errorArgs = ['cantidad_espacios'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="cantidad_espacios"
                                                   value="<?php echo e($announcement->cantidad_espacios); ?>" required autocomplete="name" autofocus>

                                            <?php $__errorArgs = ['cantidad_espacios'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <label for="image" class="col-md-4 col-form-label">Foto</label>

                                        <div class="col-md-6">
                                            <img class="img-fluid" id="image"
                                                 src="<?php echo e(asset('storage/' . $announcement->image)); ?>" alt="">
                                        </div>
                                    </div>

                                    <div class="row justify-content-center">
                                        <a href="<?php echo e(asset('storage/'.@$announcement->file_announcement)); ?>" target="_blank"> Descargar Convocatoria</a>
                                    </div>
                                    <div class="row mb-5 justify-content-center">
                                        <div class="col-12 col-sm-4">
                                            <a class="btn btn-primary bg-blue-dark" data-bs-dismiss="modal">
                                                Cerrar
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        
        function selectedAll(){
            $('input[type="checkbox"]').prop('checked', true);
        }
        function addDataChecks(name='selected_checks'){
            let checked = []
            $("input[name='users[]']:checked").each(function ()
            {
                checked.push(parseInt($(this).val()));
            });
            // const clients_selected = clients.filter(item=>checked.includes(item.id))
            /*const email_clients = clients_selected.map(
                item=> item.email?`<p class="text-start mb-0"> ${item.email}</p>`:''
            )*/
            $('#'+name).val(checked.join(','));
            // $('#body-chat').html(email_clients.join(''));
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ivanovic/Desktop/Projects/laravell/project parqueo/repositori/Tis2023/parqueo/resources/views/pages/parking/list_announcement.blade.php ENDPATH**/ ?>