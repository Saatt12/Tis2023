<div>
    <div class="modal fade" id="<?php echo e($name); ?>" data-bs-backdrop="static" data-bs-keyboard="false"
         tabindex="-1" aria-labelledby="<?php echo e($name); ?>Label" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-red-cherry text-pink-light justify-content-center">
                    <h1 class="modal-title fs-5 text-center" id="<?php echo e($name); ?>Label"><?php echo e($title); ?>

                    </h1>
                </div>
                <div class="modal-body">
                    <div class="text-center ">
                        <div class="row max-height-70">
                            <?php echo e($slot); ?>

                            
                        </div>
                        <div class="row justify-content-center">
                            <div class="col-4">
                                <button type="button" class="btn btn-secondary bg-blue-dark"
                                        data-bs-dismiss="modal">Cerrar</button>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/ivanovic/Desktop/Projects/laravell/project parqueo/repositori/Tis2023/parqueo/resources/views/components/modals/list-payment.blade.php ENDPATH**/ ?>