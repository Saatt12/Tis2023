<?php $__env->startSection('content-admin'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <div class="d-flex">
        <a href="<?php echo e(url('/client')); ?>" class="btn btn-primary m-2">ir a Home</a>
        <a href="<?php echo e(url('/client/conversation_emails')); ?>" class="btn btn-primary my-2">Enviar Mensajess </a>
    </div>

    <table class="table table-striped table-blue-light">
        <thead>
        <tr>
            <th scope="col">Nombre</th>
            <th scope="col">CI</th>
            <th scope="col">Email</th>
            <th scope="col">
                <button onclick="selectedAll()" type="button" class="btn btn-primary bg-blue-dark">
                    Seleccionar Todo
                </button>
                <button
                    type="button"
                    class="btn btn-primary bg-blue-dark"
                    data-bs-toggle="modal"
                    data-bs-target="#reject-modal"
                    onclick="addDataChecks('conversations_requests')"
                >
                    Eliminar
                </button>
            </th>

        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $conversations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conversation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($conversation->receiver_id!==auth()->user()->id?$conversation->receiver->name:$conversation->sender->name); ?></td>
                <td><?php echo e($conversation->receiver_id!==auth()->user()->id?$conversation->receiver->ci:$conversation->sender->ci); ?></td>
                <td><?php echo e($conversation->receiver_id!==auth()->user()->id?$conversation->receiver->email:$conversation->sender->email); ?></td>
                <td>
                    <div class="row justify-content-center">
                        <div class="col-3">
                            <a
                                href="<?php echo e(url('/client/conversations_messages/'.$conversation->id)); ?>"
                                class="text-blue-dark text-decoration-none"
                            > Ver </a>
                        </div>
                        <div class="col-1">
                    <input type="checkbox" name="items[]" value="<?php echo e($conversation->id); ?>" class="form-check-input">

                        </div></div>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php if (isset($component)) { $__componentOriginal2a30ae47a4885c1b5699470a97884dd83c4fadc4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Modals\GenericModal::class, ['name' => 'reject-modal','title' => 'Confirmar']); ?>
<?php $component->withName('generic-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('content', null, ['class' => '']); ?> 
            <form action="<?php echo e(route('conversation_emails.delete_client')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <p>
                    ¿Deseas eliminar estos reclamos?
                </p>
                <input type="hidden" id="conversations_requests" name="conversation_ids">
                <div class="row justify-content-center">
                    <div class="col-4">
                        <button type="button" class="btn btn-secondary bg-blue-dark"
                                data-bs-dismiss="modal">Cerrar</button>
                    </div>
                    <div class="col-4">
                        <button type="submit" class="btn btn-secondary bg-blue-dark"
                                data-bs-dismiss="modal">Aceptar</button>
                    </div>
                </div>
            </form>
         <?php $__env->endSlot(); ?>
         <?php $__env->slot('buttons', null, ['class' => '']); ?>  <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2a30ae47a4885c1b5699470a97884dd83c4fadc4)): ?>
<?php $component = $__componentOriginal2a30ae47a4885c1b5699470a97884dd83c4fadc4; ?>
<?php unset($__componentOriginal2a30ae47a4885c1b5699470a97884dd83c4fadc4); ?>
<?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        function selectedAll(){
            $('input[type="checkbox"]').prop('checked', true);
        }
        function addDataChecks(name='selected_checks'){
            let checked = []
            $("input[name='items[]']:checked").each(function ()
            {
                checked.push(parseInt($(this).val()));
            });
            $('#'+name).val(checked.join(','));
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ivanovic/Desktop/Projects/laravell/project parqueo/repositori/Tis2023/parqueo/resources/views/page_client/messages/list.blade.php ENDPATH**/ ?>