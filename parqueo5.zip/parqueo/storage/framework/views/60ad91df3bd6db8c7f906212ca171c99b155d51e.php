<?php $__env->startSection('content-admin'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <div class="container">
        <div class="w-100 px-3">
            <div class="row pt-3">
                <div class="col-7">
                    <img class="w-100" src="<?php echo e(asset('images/photo_parqueo.svg')); ?>" alt="">
                </div>
                <div class="col-5 d-flex align-items-center justify-content-center">
                    <div>
                        <div class="d-flex justify-content-center mb-4">
                            <?php if(@$user_permission->contains('crear_convocatoria')): ?>
                            <a href="<?php echo e(url('/announcements/create')); ?>" class="btn btn-danger bg-red-cherry me-4">Convocatoria</a>
                            <?php endif; ?>
                            <?php if(@$user_permission->contains('ver_convocatoria')): ?>
                            <a href="<?php echo e(url('/announcements')); ?>" class="btn btn-danger bg-red-cherry">Lista Convocatoria</a>
                                <?php endif; ?>
                        </div>
                        <div class="d-flex justify-content-center mb-4">
                            <?php if(@$user_permission->contains('ver_vehiculos')): ?>
                            <a href="<?php echo e(url('/vehicles')); ?>" class="btn btn-danger bg-red-cherry">Vehiculos registrados</a>
                            <?php endif; ?>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <div class="row align-content-stretch">
            <?php $__currentLoopData = $parkings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-2">
                    <?php if($parking->status==='unavailable'): ?>
                        <p class="text-red-cherry"><?php echo e($parking->name); ?></p>
                    <?php else: ?>
                        <p><?php echo e($parking->name); ?></p>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        
        function selectedAll(){
            $('input[type="checkbox"]').prop('checked', true);
        }
        function addDataChecks(name='selected_checks'){
            let checked = []
            $("input[name='users[]']:checked").each(function ()
            {
                checked.push(parseInt($(this).val()));
            });
            // const clients_selected = clients.filter(item=>checked.includes(item.id))
            /*const email_clients = clients_selected.map(
                item=> item.email?`<p class="text-start mb-0"> ${item.email}</p>`:''
            )*/
            $('#'+name).val(checked.join(','));
            // $('#body-chat').html(email_clients.join(''));
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ivanovic/Desktop/Projects/laravell/project parqueo/repositori/Tis2023/parqueo/resources/views/pages/parking/show.blade.php ENDPATH**/ ?>