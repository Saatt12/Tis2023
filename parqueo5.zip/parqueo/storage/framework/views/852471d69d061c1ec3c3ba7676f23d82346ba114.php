<?php $__env->startSection('content-admin'); ?>
    <div class="row">
        <div class="col-1 d-flex flex-column align-items-center justify-content-center">
            <a class="btn btn-primary bg-blue-dark" href="<?php echo e(url('/reports')); ?>">
                Atras
            </a>
        </div>
        <div class="col-10">
            <form class="row my-3" action="<?php echo e(route('search_report_payments')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="col-5">
                    <div class="row mb-3">
                        <label for="date_initial" class="col-6 col-form-label">fecha inicial de registro</label>
                        <div class="col-6">
                            <input id="date_initial" type="date"
                                   class="form-control <?php $__errorArgs = ['date_initial'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="date_initial"
                                   value="<?php echo e($date_initial); ?>" autocomplete="name" autofocus>
                            <?php $__errorArgs = ['date_initial'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($message); ?></strong>
                       </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label for="date_fin" class="col-6 col-form-label">fecha final de registro</label>

                        <div class="col-6">
                            <input id="date_fin" type="date"
                                   class="form-control <?php $__errorArgs = ['date_fin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="date_fin"
                                   value="<?php echo e($date_fin); ?>" autocomplete="name" autofocus>

                            <?php $__errorArgs = ['date_fin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($message); ?></strong>
                        </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="col-4 d-flex flex-column align-items-center justify-content-center">
                    <div class="row">
                        <div class="col-3 d-flex flex-column align-items-center justify-content-center">
                            <label for="name" class="">Usuario</label>
                        </div>
                        <div class="col-9">
                            <input id="name" type="text"
                                   class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name"
                                   value="<?php echo e($name); ?>" autocomplete="name" autofocus>

                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($message); ?></strong>
                       </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                </div>

                <div class="col-1 d-flex flex-column align-items-center justify-content-center">
                    <div class="">
                        <button type="submit" class="btn btn-primary bg-blue-dark">
                            Buscar
                        </button>
                    </div>
                </div>
            </form>
        </div>
        <div class="col-1 d-flex flex-column align-items-center justify-content-center">
            <form method="POST" action="<?php echo e(route('export_report_payments')); ?>" target="_blank">
                <?php echo csrf_field(); ?>
                <input id="date_initial" type="hidden" value="<?php echo e($date_initial); ?>" name="date_initial">
                <input id="date_initial" type="hidden" value="<?php echo e($date_fin); ?>" name="date_fin">
                <input id="date_initial" type="hidden" value="<?php echo e($name); ?>" name="name">
                <button type="submit" class="btn btn-primary bg-blue-dark"> PDF</button>
            </form>
        </div>
    </div>
    <table class="table table-striped table-blue-light">
        <thead>
        <tr>
            <th scope="col">Nombre</th>
            <th scope="col">Estado</th>
            <th scope="col">Detalle de pago</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(@$payment['user']->name); ?></td>
                <td><?php echo e(@$payment['status']?$payment['status']:'Pagado'); ?></td>
                <td>
                    <a onclick="selectedPayToShow(<?php echo e($payment->id); ?>)"
                       class="btn btn-secondary bg-blue-dark" data-bs-toggle="modal"
                       data-bs-target="#payment_<?php echo e($payment->id); ?>"> Ver </a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if (isset($component)) { $__componentOriginal2a30ae47a4885c1b5699470a97884dd83c4fadc4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Modals\GenericModal::class, ['name' => 'payment_'.e($payment->id).'','title' => 'Pago']); ?>
<?php $component->withName('generic-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
             <?php $__env->slot('content', null, ['class' => '']); ?> 
                <div class="row mb-3">
                    <label for="type" class="col-md-4 col-form-label">Modalidad de Pago</label>
                    <div class="col-md-6">
                        <select class="form-control" name="type" disabled>
                            <option value="" <?php echo e(!$payment->type ? 'selected' : ''); ?>> Selecciona una
                                Modalidad</option>
                            <option value="qr" <?php echo e($payment->type == 'qr' ? 'selected' : ''); ?>> Qr</option>
                            <option value="manual" <?php echo e($payment->type == 'manual' ? 'selected' : ''); ?>> Manual
                            </option>
                        </select>
                    </div>
                </div>
                <?php if(@$payment->type === 'qr'): ?>
                    <div>
                        <div class="row mb-3 justify-content-center">
                            <div class="col-5">
                                <div id="qrcode_show_<?php echo e($payment->id); ?>" class="qrcode_show"></div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                <div class="row mb-3">
                    <label for="number" class="col-md-4 col-form-label">Nro de recibo</label>
                    <div class="col-md-6">
                        <input type="number" class="form-control" name="number"
                               value="<?php echo e($payment->id); ?>" disabled>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="plan" class="col-md-4 col-form-label">Plan de pago</label>
                    <div class="col-md-6">
                        <select class="form-control" name="plan" disabled>
                            <option value="" selected> Selecciona un plan</option>
                            <option value="anual" <?php echo e(@$payment->plan === 'anual' ? 'selected' : ''); ?>> Anual
                            </option>
                            <option value="mensual" <?php echo e(@$payment->plan === 'mensual' ? 'selected' : ''); ?>> Mensual
                            </option>
                        </select>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="amount" class="col-md-4 col-form-label">Monto</label>

                    <div class="col-md-6">
                        <input type="number" class="form-control" name="amount"
                               value="<?php echo e($payment->amount); ?>" disabled>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="amount" class="col-md-4 col-form-label">Documento Adjunto</label>

                    <div class="col-md-6">
                        <a href="<?php echo e(asset('storage/'.@$payment->comprobante)); ?>" target="_blank"><?php echo e(@$payment->comprobante); ?></a>
                    </div>
                </div>
                <?php if(@$payment->count): ?>
                    <div class="row mb-3 ">
                        <label for="count" class="col-md-4 col-form-label">Meses</label>
                        <div class="col-md-6">
                            <select class="form-control" name="count" disabled>
                                <option value="" selected> Selecciona un meses</option>
                                <?php for($i = 1; $i <= 12; $i++): ?>
                                    <option value="<?php echo e($i); ?>"
                                        <?php echo e(@$payment->count === $i ? 'selected' : ''); ?>> <?php echo e($i); ?>

                                        <?php echo e($i == 1 ? 'mes' : 'meses'); ?> </option>
                                <?php endfor; ?>
                            </select>
                        </div>
                    </div>
                <?php endif; ?>
                <div class="row mb-3">
                    <label for="user" class="col-md-4 col-form-label">Nombre</label>
                    <div class="col-md-6">
                        <input type="text" class="form-control" readonly disabled
                               value="<?php echo e(@$payment->user->name); ?>">
                    </div>
                </div>

             <?php $__env->endSlot(); ?>
             <?php $__env->slot('buttons', null, []); ?> 
                <div class="row justify-content-center">
                    <div class="col-4">
                        <button type="button" class="btn btn-secondary bg-blue-dark"
                                data-bs-dismiss="modal">Cerrar</button>
                    </div>
                </div>
             <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2a30ae47a4885c1b5699470a97884dd83c4fadc4)): ?>
<?php $component = $__componentOriginal2a30ae47a4885c1b5699470a97884dd83c4fadc4; ?>
<?php unset($__componentOriginal2a30ae47a4885c1b5699470a97884dd83c4fadc4); ?>
<?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ivanovic/Desktop/Projects/laravell/project parqueo/repositori/Tis2023/parqueo/resources/views/pages/reports/reports_payments.blade.php ENDPATH**/ ?>