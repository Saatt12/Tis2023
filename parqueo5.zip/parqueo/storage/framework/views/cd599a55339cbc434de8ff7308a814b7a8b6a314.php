<?php $__env->startSection('content-admin'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <div class="container">
        <div class="row justify-content-center pt-5">
            <div class="col-md-7 col-lg-5">
                <div class="bg-red-cherry pt-3 pb-3 text-center fw-bolder text-white mb-2">Correos</div>
                <div class="card">
                    <div class="card-body">
                        
                        <div class="ps-3 border-0">
                            <button type="button" onclick="selectedAll()" class="btn btn-primary bg-grey-light border-0 text-black"> Seleccionar todos</button>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row py-1">
                                <div class="col-10">
                                    <label for="check_<?php echo e($user->id); ?>" class="text-wrap"><?php echo e($user->email); ?></label>
                                </div>
                                <div class="col-2">
                                    <input id="check_<?php echo e($user->id); ?>" type="checkbox" name="users[]" value="<?php echo e($user->id); ?>" class="form-check-input bg-grey-light checkbox-email">
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="row mb-5 mt-3 justify-content-center">
                                <div class="col-md-3"></div>


                                <div class="col-md-4 ">
                                    <a class="btn btn-primary bg-blue-dark" href="<?php echo e(url('/client/conversations')); ?>">
                                        Cancelar
                                    </a>
                                </div>
                                <div class="col-md-4">
                                    <button
                                        type="button"
                                        data-bs-toggle="modal"
                                        onclick="addDataChecks('receivers')"
                                        data-bs-target="#send-many-messages"
                                        class="btn btn-primary bg-blue-dark">
                                        Aceptar
                                    </button>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <?php if (isset($component)) { $__componentOriginal2a30ae47a4885c1b5699470a97884dd83c4fadc4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Modals\GenericModal::class, ['name' => 'send-many-messages','title' => 'Confirmar']); ?>
<?php $component->withName('generic-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
             <?php $__env->slot('content', null, ['class' => '']); ?> 
                <button type="button" class="btn btn-primary bg-grey-light border-0 text-black" data-bs-dismiss="modal"> Seleccionar Correos</button>
                <h5 class="py-1">Correos de reenvio de mensajes</h5>
                <div class="content-chat position-relative">
                    <div id="body-chat" class="chat-body d-block left-content-chat">
                    </div>
                    <div class="footer-chat position-absolute pe-3">
                        <hr class="m-0">
                        <form class="bg-white" action="<?php echo e(route('conversation_emails.store_client')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="bg-white w-100 py-2 d-flex">
                                <input autocomplete="off" name="message" type="text" class="bg-pick-chat rounded-pill px-3 flex-grow-1">
                                <input type="hidden" name="receivers" id="receivers">
                                <button type="submit" class="btn-icon bg-white">
                                    <img src="<?php echo e(asset('images/icon_send_message.png')); ?>" alt="">
                                </button>

                            </div>
                        </form>
                    </div>
                </div>
             <?php $__env->endSlot(); ?>
             <?php $__env->slot('buttons', null, ['class' => '']); ?>  <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2a30ae47a4885c1b5699470a97884dd83c4fadc4)): ?>
<?php $component = $__componentOriginal2a30ae47a4885c1b5699470a97884dd83c4fadc4; ?>
<?php unset($__componentOriginal2a30ae47a4885c1b5699470a97884dd83c4fadc4); ?>
<?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        const users =  <?php echo json_encode($users, 15, 512) ?>;
        function selectedAll(){
            $('input[type="checkbox"]').prop('checked', true);
        }
        function addDataChecks(name='selected_checks'){
            let checked = []
            $("input[name='users[]']:checked").each(function ()
            {
                checked.push(parseInt($(this).val()));
            });
            const users_selected = users.filter(item=>checked.includes(item.id))
            const email_users = users_selected.map(
                item=> item.email?`<p class="text-start mb-0"> ${item.email}</p>`:''
            )
            $('#'+name).val(checked.join(','));
            $('#body-chat').html(email_users.join(''));
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ivanovic/Desktop/Projects/laravell/project parqueo/repositori/Tis2023/parqueo/resources/views/page_client/messages/correos.blade.php ENDPATH**/ ?>