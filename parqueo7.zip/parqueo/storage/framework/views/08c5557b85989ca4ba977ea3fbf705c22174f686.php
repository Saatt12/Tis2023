<?php $__env->startSection('content-admin'); ?>
    <div class="container">
        <div class="row justify-content-center pt-5">
            <div class="col-md-8 col-lg-7">
                <div class="bg-red-cherry pt-3 pb-3 text-center fw-bolder text-white mb-2">Editar Rol</div>
                <div class="card">
                    <div class="card-body">
                        <form class="ps-3" method="POST" action="<?php echo e(route('role.update', $role->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="row mb-3">
                                <label for="name" class="col-md-4 col-form-label">Nombre Rol</label>

                                <div class="col-md-6">
                                    <input id="nom_role" type="text"
                                           class="form-control <?php $__errorArgs = ['nom_role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nom_role"
                                           value="<?php echo e(@$role->nom_role); ?>" required autocomplete="nom_role" autofocus>

                                    <?php $__errorArgs = ['nom_role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <label for="nom_role" class="col-md-4 col-form-label">Permisos</label>
                                <div class="col-md-6">
                                    <div class="row">
                                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-12">
                                                <div class="form-check">
                                                    <input class="form-check-input <?php echo e($permission->type!==@$permissions[$key-1]->type?'parent-checkbox':$permission->type); ?>"
                                                           name="permissions[]"
                                                           data-target=".<?php echo e($permission->type); ?>"
                                                           <?php echo e($permission->type===@$permissions[$key-1]->type?'disabled':''); ?>

                                                           <?php echo e($role_permissions->contains($permission->id)?'checked':''); ?>

                                                           type="checkbox" value="<?php echo e($permission->id); ?>"
                                                           id="flexCheckDefault">
                                                    <label class="form-check-label " for="flexCheckDefault">
                                                        <?php if($permission->type!==@$permissions[$key-1]->type): ?>
                                                            <strong><?php echo e($permission->name); ?> </strong>
                                                        <?php else: ?>
                                                            <?php echo e($permission->name); ?>

                                                        <?php endif; ?>
                                                    </label>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row mb-5 justify-content-center">
                                <div class="col-md-3"></div>

                                <div class="col-md-4">
                                    <button type="submit" class="btn btn-primary bg-blue-dark">
                                        Aceptar
                                    </button>
                                </div>
                                <div class="col-md-4 ">
                                    <a class="btn btn-primary bg-blue-dark" href="<?php echo e(url('/roles')); ?>">
                                        Cancelar
                                    </a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('.parent-checkbox').on('change', function() {
                let target = $(this).data('target');
                let isChecked = $(this).prop('checked');
                $(target).prop('checked', isChecked).prop('disabled', !isChecked);
            });
            $('.parent-checkbox').trigger('change');
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ivanovic/Desktop/Projects/laravell/project parqueo/repositori/Tis2023/parqueo/resources/views/pages/roles/show.blade.php ENDPATH**/ ?>