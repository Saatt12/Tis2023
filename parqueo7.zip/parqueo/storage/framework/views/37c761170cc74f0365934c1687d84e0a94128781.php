<?php $__env->startSection('content-admin'); ?>
    <div class="container">
        <div class="row justify-content-center mt-4">
            <div class="col-8 col-md-8 col-lg-7">
                <div class="bg-red-cherry text-white py-3">
                    <h4 class="text-center mb-0">Chat</h4>
                </div>
                <div class="content-chat position-relative">
                    <div id="body-chat" class="chat-body">
                        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($message->sender_id !== $conversation->client_id): ?>
                                <div class="right-content-chat my-2">
                                    <div class="content-message p-3">
                                        <?php echo e($message->message); ?>

                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="left-content-chat my-2">
                                    <div class="content-message p-3">
                                        <?php echo e($message->message); ?>

                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="footer-chat position-absolute pe-3">
                        <hr class="m-0">
                        <form class="bg-white" action="<?php echo e(route('send_conversation_message_client')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="bg-white w-100 py-2 d-flex">
                                <input autocomplete="off" name="message" type="text" class="bg-pick-chat rounded-pill px-3 flex-grow-1">
                                <input type="hidden" name="conversation_id" value="<?php echo e($conversation->id); ?>">
                                <label for="conversation-file" class="bg-white">
                                    <img src="<?php echo e(asset('images/upload_file.png')); ?>" alt="">
                                </label>
                                <input id="conversation-file" type="file" name="file" class="visually-hidden">
                                <button type="submit" class="btn-icon bg-white">
                                    <img src="<?php echo e(asset('images/icon_send_message.png')); ?>" alt="">
                                </button>

                            </div>
                            <div class="row justify-content-center ">
                                <div class="col-4">
                                    <a href="<?php echo e(url('/client/conversations')); ?>" class="btn btn-primary bg-blue-dark"> Cerrar </a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#body-chat').scrollTop($(document).height());
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ivanovic/Desktop/Projects/laravell/project parqueo/repositori/Tis2023/parqueo/resources/views/page_client/messages/message.blade.php ENDPATH**/ ?>