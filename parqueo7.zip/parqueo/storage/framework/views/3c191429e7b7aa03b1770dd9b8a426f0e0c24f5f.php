<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->


<html >
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>


<head>

    <title>Membrecia IDP </title>
</head>


<style type="text/css">
    body{
        font-family: sans-serif;
        font-size: 12px;
        height: 50%;
        padding: 0px 0px 0px 0px;
        margin-top: -10px;
    }
    b{
        font-family: sans-serif;
    }
    .cuerpo tr td{

        border-collapse: collapse;
        border-top: 1px dotted rgb(0,0,0);
        border-bottom: 1px dotted rgb(0,0,0);
        border-left: 1px dotted rgb(0,0,0);
        border-right: 1px dotted rgb(0,0,0);
        border-left: none;
        border-bottom: none;
    }
    header {
        position: fixed;
        top: -60px;
        left: 0px;
        right: 0px;
        height: 50px;

        /** Extra personal styles **/
        background-color: #03a9f4;
        color: white;
        text-align: center;
        line-height: 35px;
    }
</style>
<body>
<div class="main">
    <table class="cuerpoo" align="left" cellpadding="0" cellspacing="0" width="100%" style="margin:5px;  page-break-inside: avoid;width:100%;" >
        <tr  classname="trini" style="font-size: 12px; text-align:left;">
            <td style="width: 40%;">
                <table>
                    <tbody>
                    <tr >
                        
                       
                    </tr>
                    </tbody>
                </table>

            </td>
            <td style="width: 30%"></td>
            <td  style="width: 30%;">
                <p style="text-align: center;"><b>PARQUEO UMSS </b></p>
                   </td>
        </tr>
    </table>
   

        <div class="table-responsive pb-2" >
            <table  class="cuerpo" align="left" cellpadding="0" cellspacing="0" width="100%" style="margin:5px;  page-break-inside: avoid;width:100%; border-left: 1px dotted rgb(0,0,0); border-top: 1px dotted rgb(0,0,0);border-bottom: 1px dotted rgb(0,0,0);border-right: 1px dotted rgb(0,0,0)" >
                <thead class="table-info">
                <tr>
                    <th colspan="8" >
                        <h3 class="h2" style="text-align:center; margin-top: 0%; padding-top: 0%; border: 1px solid rgb(0,0,0); color: rgb(10, 1, 59);">Convocatorias</h3>
                    </th>
                </tr>

                <tr>

                </tr>
                <tr>

                    <th>fecha emision</th>
                    <th>fecha fin emision</th>
                    <th>Descuento</th>
                    <th>Multa</th>
                    <th>Monto mensual </th>
                    <th>Monto anual</th>
                    <th>Cantidad Esp</th>
                    <th>Imagen</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td ><?php echo e($item->fecha_inicio); ?></td>
                        <td ><?php echo e($item->fecha_fin); ?></td>
                        <td ><?php echo e($item->descuento); ?></td>
                        <td ><?php echo e($item->multa); ?></td>
                        <td ><?php echo e($item->monto_mes); ?> </td>
                        <td ><?php echo e($item->monto_anual); ?></td>
                        <td ><?php echo e($item->cantidad_espacios); ?></td>
                        <td >
                            <img src="<?php echo e($item->image); ?>" alt=""  style="max-width: 100px">
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
               
            </table>
        </div>

</div>

</div>
</body>
<?php /**PATH /home/ivanovic/Desktop/Projects/laravell/project parqueo/repositori/Tis2023/parqueo/resources/views/pages/template_export/pdf_announcements.blade.php ENDPATH**/ ?>